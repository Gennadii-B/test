package Entity;

/**
 * Created by дима on 30.10.2016.
 */
public class Driver {
    private String name;
    private String telephone;
}
