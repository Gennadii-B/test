package Utilities;

import Entity.Car;

import java.util.ArrayList;

/**
 * Created by дима on 30.10.2016.
 */
public class Initialization {
    public static ArrayList<Car> initCarArray() {
        return null;
    }
}
