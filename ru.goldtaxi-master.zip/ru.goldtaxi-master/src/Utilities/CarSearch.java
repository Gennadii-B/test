package Utilities;

import Entity.*;

import java.util.ArrayList;

/**
 * Created by дима on 30.10.2016.
 */
public class CarSearch {
    public static void searchFreeCar(ArrayList<Car> CarArrayList, Order order) {

    }
}
