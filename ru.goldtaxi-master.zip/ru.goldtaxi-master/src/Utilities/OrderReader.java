package Utilities;

import Entity.Order;

/**
 * Created by дима on 30.10.2016.
 */
public class OrderReader {
    public static Order orderRead() {
        return null;
    }

    ;
}
